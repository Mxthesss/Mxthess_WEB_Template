Made by: © | Mxthess
For any help contact me on discord: ✞ Mxthess ✞⁹⁹⁹⁺#1157
If something doesnt working still you have chance to fix by yourself or contact me .-.
In addition, there is some text in style.css so that people can't simply resell the site, this site is free, but it doesn't mean that someone will take my job and remake it for their own benefit.